
import game.AbstractExecutioner;
import game.AbstractGuesser;
import game.Excecutioner;
import game.Guesser;
import game.HangmanGame;

import java.util.Scanner;
import game.StandardExecutioner;
import game.UserGuesser;
import util.ConsoleReader;
import util.HangmanDictionary;

/**
 * This class launches the Hangman game and plays once.
 * 
 * @author Robert C. Duvall
 * @author Shannon Duvall
 */
public class Main {
    public static final String DICTIONARY = "C:\\Users\\Owner\\Downloads\\HangmanLab1\\HangmanLab1\\data\\lowerwords.txt";
    public static final int NUM_LETTERS = 6;
    public static final int NUM_MISSES = 8;

    public static void main(String[] args) {
        // new HangmanGame(new HangmanDictionary(DICTIONARY), NUM_LETTERS,
        // NUM_MISSES).play();
        // Prompt user for role selection
        // HangmanDictionary dictionary = new HangmanDictionary(DICTIONARY);

        // System.out.println("Choose your role:");
        // System.out.println("1. Guesser");
        // System.out.println("2. Executioner");
        // int choice = ConsoleReader.promptInt("Enter 1 or 2: ");

        // if (choice == 1) {
        // // Play as Guesser
        // Guesser guesser = new Guesser(NUM_MISSES);
        // HangmanGame game = new HangmanGame(dictionary, NUM_LETTERS, NUM_MISSES);
        // game.play();
        // } else if (choice == 2) {
        // // Play as Executioner
        // Excecutioner executioner = new Excecutioner(dictionary, NUM_LETTERS);
        // HangmanGame game = new HangmanGame(dictionary, NUM_LETTERS, NUM_MISSES);
        // game.play();
        // } else {
        // System.out.println("Invalid choice. Please run the program again and select 1
        // or 2.");
        // }
        Scanner scanner = new Scanner(System.in);
        System.out.println("Choose your role:");
        System.out.println("1. Guesser");
        System.out.println("2. Executioner");
        System.out.print("Enter 1 or 2: ");
        int choice = scanner.nextInt();

        HangmanDictionary dictionary = new HangmanDictionary(DICTIONARY);
        AbstractGuesser guesser = null;
        AbstractExecutioner executioner = null;

        if (choice == 1) {
            guesser = new UserGuesser(NUM_MISSES);
            executioner = new StandardExecutioner(dictionary, NUM_LETTERS);
        } else if (choice == 2) {
            guesser = new UserGuesser(NUM_MISSES); // Assume AutoGuesser is implemented similarly
            executioner = new StandardExecutioner(dictionary, NUM_LETTERS);
        }

        if (guesser != null && executioner != null) {
            HangmanGame game = new HangmanGame(guesser, executioner);
            game.play();

            // Close scanner if it's a UserGuesser
            if (guesser instanceof UserGuesser) {
                ((UserGuesser) guesser).closeScanner();
            }
        }

        scanner.close();
    }
}
