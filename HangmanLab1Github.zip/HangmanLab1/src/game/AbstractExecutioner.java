package game;

import util.DisplayWord;

public abstract class AbstractExecutioner {
    protected String mySecretWord;
    protected DisplayWord myCurWord;

    public AbstractExecutioner(String secretWord) {
        this.mySecretWord = secretWord.toLowerCase();
        this.myCurWord = new DisplayWord(mySecretWord);
    }

    public abstract boolean checkGuess(char guess); // To be customized by subclasses

    public boolean isGameWon() {
        return myCurWord.equals(mySecretWord);
    }

    public DisplayWord getCurWord() {
        return myCurWord;
    }

    public String getSecretWord() {
        return mySecretWord;
    }
}
