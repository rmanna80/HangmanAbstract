package game;

import java.util.Scanner;

public class Guesser {

    private StringBuilder lettersLeftToGuess;
    private int numGuessesLeft;
    private Scanner scanner;

    public Guesser(int numGuesses) {
        this.numGuessesLeft = numGuesses;
        this.lettersLeftToGuess = new StringBuilder("abcdefghijklmnopqrstuvwxyz");
        this.scanner = new Scanner(System.in);
    }

    public int getNumGuessesLeft() {
        return numGuessesLeft;
    }

    public StringBuilder getLettersLeftToGuess() {
        return lettersLeftToGuess;
    }

    public char makeGuess() {

        System.out.println("Enter your guess: ");
        char guess = scanner.nextLine().toLowerCase().charAt(0);
        while (!Character.isAlphabetic(guess) || lettersLeftToGuess.indexOf(Character.toString(guess)) == -1) {
            System.out.println("Invalid input. Please enter a letter that has not been guessed:");
            guess = scanner.nextLine().toLowerCase().charAt(0);
        }
        return guess;

    }

    public void recordGuess(char guess) {

        int index = lettersLeftToGuess.indexOf(Character.toString(guess));
        if (index != -1) {
            lettersLeftToGuess.deleteCharAt(index);
        }

    }

    public void decrementGuesses() {
        numGuessesLeft--;
    }

    // close the scanner
    public void close() {
        scanner.close();
    }

}
