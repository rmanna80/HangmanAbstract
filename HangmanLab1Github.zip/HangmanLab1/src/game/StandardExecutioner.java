package game;

import util.HangmanDictionary;

public class StandardExecutioner extends AbstractExecutioner {
    public StandardExecutioner(HangmanDictionary dictionary, int wordLength) {
        super(dictionary.getRandomWord(wordLength));
    }

    @Override
    public boolean checkGuess(char guess) {
        boolean correct = mySecretWord.indexOf(guess) >= 0;
        if (correct) {
            myCurWord.update(guess, mySecretWord);
        }
        return correct;
    }
}
