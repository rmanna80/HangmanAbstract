package game;

import java.util.Scanner;

public class UserGuesser extends AbstractGuesser {
    private Scanner scanner;

    public UserGuesser(int numGuesses) {
        super(numGuesses);
        this.scanner = new Scanner(System.in);
    }

    @Override
    public char makeGuess() {
        System.out.println("Enter your guess: ");
        return scanner.nextLine().charAt(0);
    }

    // Make sure to close the scanner when done
    public void closeScanner() {
        scanner.close();
    }
}
