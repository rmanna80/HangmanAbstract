package game;

public abstract class AbstractGuesser {
    protected int numGuessesLeft;
    protected StringBuilder lettersLeftToGuess;

    public AbstractGuesser(int numGuesses) {
        this.numGuessesLeft = numGuesses;
        this.lettersLeftToGuess = new StringBuilder("abcdefghijklmnopqrstuvwxyz");
    }

    public abstract char makeGuess(); // For subclasses to define how to make a guess

    public void recordGuess(char guess) {
        int index = lettersLeftToGuess.indexOf(String.valueOf(guess));
        if (index != -1) {
            lettersLeftToGuess.deleteCharAt(index);
        }
    }

    public void decreaseGuessCount() {
        numGuessesLeft--;
    }

    public int getNumGuessesLeft() {
        return numGuessesLeft;
    }

    public String getLettersLeftToGuess() {
        return lettersLeftToGuess.toString();
    }
}
