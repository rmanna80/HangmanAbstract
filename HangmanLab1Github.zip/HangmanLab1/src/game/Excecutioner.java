
package game;

import util.DisplayWord;
import util.HangmanDictionary;

public class Excecutioner {

    private String mySecretWord; // this is the secret word thats to be guessed
    private DisplayWord myCurWord; // displays the current guess to the user
    private int numGuessesLeft;

    // constructors
    public Excecutioner(HangmanDictionary dictionary, int wordLength) {
        mySecretWord = makeSecretWord(dictionary, wordLength);
        myCurWord = new DisplayWord(mySecretWord);

    }

    // this method will pick a random word that is in the dictionary
    public String makeSecretWord(HangmanDictionary dictionary, int wordLength) {
        return dictionary.getRandomWord(wordLength).toLowerCase();
    }

    public String getSecretWord() {
        return mySecretWord;
    }

    // checks if the user guessed the correct letter that is in the secret word
    public boolean chekGuess(char guess) {

        boolean correctLetter = mySecretWord.indexOf(guess) >= 0; // checks if the guess is correct
        if (correctLetter) {
            myCurWord.update(guess, mySecretWord); // update the display with the correct guess from the user
        }
        return correctLetter;
    }

    public boolean isGameWon() {
        return myCurWord.equals(mySecretWord);
    }

    public boolean isGameLost() {
        return numGuessesLeft <= 0;
    }

    public String getCurWord() {
        return myCurWord.toString();
    }

    public int getNumGuessesLeft() {
        return numGuessesLeft;
    }

}
