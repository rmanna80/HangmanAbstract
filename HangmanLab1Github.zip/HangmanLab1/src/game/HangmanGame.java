/* 
package game;

import util.ConsoleReader;
import util.DisplayWord;
import util.HangmanDictionary;

/**
 * This class represents the traditional word-guessing game Hangman
 * that plays interactively with the user.
 *
 * @author Robert C. Duvall
 * @author Shannon Duvall
 */
/* 
public class HangmanGame {
    private static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";

    // word that is being guessed
    private String mySecretWord;
    // how many guesses are remaining
    private int myNumGuessesLeft;
    // what is shown to the user
    private DisplayWord myDisplayWord;
    // tracks letters guessed
    private StringBuilder myLettersLeftToGuess;

    private Guesser guesser;
    private Excecutioner executioner;

    /**
     * Create Hangman game with the given dictionary of words to play a game with
     * words
     * of the given length and giving the user the given number of chances.
     */
/* 
public HangmanGame(HangmanDictionary dictionary, int wordLength, int numGuesses) {
    this.guesser = new Guesser(numGuesses);
    this.executioner = new Excecutioner(dictionary, wordLength);
}

/**
 * Play one complete game.
 
public void play() {
    boolean gameOver = false;
    while (!gameOver) {
        printStatus();

        char guess = guesser.makeGuess();
        guesser.recordGuess(guess);

        boolean correct = executioner.chekGuess(guess);

        if (!correct) {
            guesser.decrementGuesses();
        }

        // Determine if the game has been won or lost
        if (guesser.getNumGuessesLeft() <= 0) {
            System.out.println("YOU ARE HUNG!!!");
            gameOver = true;
        } else if (executioner.isGameWon()) {
            System.out.println("YOU WIN!!!");
            gameOver = true;
        }
    }
    System.out.println("The secret word was: " + executioner.getSecretWord());
    guesser.close(); // Ensure the scanner is closed
}

// Process a guess by updating the necessary internal state.
// private void makeGuess (char guess) {
// // do not count repeated guess as a miss
// int index = myLettersLeftToGuess.indexOf("" + guess);
// if (index >= 0) {
// recordGuess(index);
// if (! checkGuessInSecret(guess)) {
// myNumGuessesLeft -= 1;
// }
// }
// }

// Record that a specific letter was guessed
// private void recordGuess (int index) {
// myLettersLeftToGuess.deleteCharAt(index);
// }

// Returns true only if given guess is in the secret word.
// private boolean checkGuessInSecret (char guess) {
// if (mySecretWord.indexOf(guess) >= 0) {
// myDisplayWord.update(guess, mySecretWord);
// return true;
// }
// return false;
// }

// Returns a secret word.
// private String makeSecretWord(HangmanDictionary dictionary, int wordLength) {
// return dictionary.getRandomWord(wordLength).toLowerCase();
// }

// Returns true only if the guesser has guessed all letters in the secret word.
// private boolean isGameWon () {
// return myDisplayWord.equals(mySecretWord);
// }

// Returns true only if the guesser has used up all their chances to guess.
// private boolean isGameLost () {
// return myNumGuessesLeft == 0;
// }

// Print game stats
private void printStatus() {
    System.out.println("Current word: " + executioner.getCurWord());
    System.out.println("Misses left: " + guesser.getNumGuessesLeft());
    System.out.println("Letters not yet guessed: " + guesser.getLettersLeftToGuess());
    System.out.println();
}
}

*/
package game;

public class HangmanGame {
    private AbstractGuesser guesser;
    private AbstractExecutioner executioner;

    public HangmanGame(AbstractGuesser guesser, AbstractExecutioner executioner) {
        this.guesser = guesser;
        this.executioner = executioner;
    }

    public void play() {
        boolean gameOver = false;
        while (!gameOver) {
            printStatus();

            char guess = guesser.makeGuess();
            guesser.recordGuess(guess);

            boolean correct = executioner.checkGuess(guess);
            if (!correct) {
                guesser.decreaseGuessCount();
            }

            if (guesser.getNumGuessesLeft() <= 0) {
                System.out.println("YOU ARE HUNG!!!");
                gameOver = true;
            } else if (executioner.isGameWon()) {
                System.out.println("YOU WIN!!!");
                gameOver = true;
            }
        }

        System.out.println("The secret word was: " + executioner.getSecretWord());
    }

    private void printStatus() {
        System.out.println(executioner.getCurWord());
        System.out.println("# misses left = " + guesser.getNumGuessesLeft());
        System.out.println("letters not yet guessed = " + guesser.getLettersLeftToGuess());
        System.out.println();
    }
}
